
#!/usr/bin/env python3
from mrjob.job import MRJob
from mrjob.step import MRStep
import re
from collections import defaultdict
import math

class Query(MRJob):

    def configure_args(self):
        super(Query, self).configure_args()
        self.add_passthru_arg('query', type=str, help='Query text')
        self.add_passthru_arg('num_results', type=int, help='Number of results')

    def mapper_extract_terms(self, _, line):
        ARTICLE_ID, TITLE, SECTION_TITLE, SECTION_TEXT = line.split("\t")
        text = TITLE + " " + SECTION_TITLE + " " + SECTION_TEXT
        terms = re.findall(r'\w+', text.lower())
        for term in terms:
            yield term, ARTICLE_ID

    def reducer_calculate_scores(self, term, article_ids):
        # Count term frequency (TF) for the query
        tf_query = defaultdict(int)
        for article_id in article_ids:
            tf_query[article_id] += 1

        # Calculate IDF (Inverse Document Frequency) for the query term
        idf_query = math.log10(5000000 / (len(tf_query) + 1))

        # Calculate TF-IDF score for the query term
        for article_id, freq in tf_query.items():
            tf_idf_query = (1 + math.log10(freq)) * idf_query
            yield article_id, tf_idf_query

    def reducer_aggregate_scores(self, article_id, scores):
        # Sum up the TF-IDF scores for each document
        total_score = sum(scores)
        yield None, (total_score, article_id)

    def reducer_sort_results(self, _, total_scores):
        # Sort the results by TF-IDF score
        sorted_scores = sorted(total_scores, reverse=True)[:self.options.num_results]
        for score, article_id in sorted_scores:
            yield article_id, score

    def steps(self):
        return [
            MRStep(mapper=self.mapper_extract_terms),
            MRStep(reducer=self.reducer_calculate_scores),
            MRStep(reducer=self.reducer_aggregate_scores),
            MRStep(reducer=self.reducer_sort_results)
        ]

if __name__ == '__main__':
    Query.run()

