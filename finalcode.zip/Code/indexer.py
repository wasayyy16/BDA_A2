#!/usr/bin/env python3
import sys
from mrjob.job import MRJob
from mrjob.step import MRStep
import csv
import re
from collections import defaultdict
import math
import logging

class Indexer(MRJob):

    def mapper_extract_terms(self, _, line):
        try:
            # Parse the CSV line into a list
            row = next(csv.reader([line]))
            ARTICLE_ID, TITLE, SECTION_TITLE, SECTION_TEXT = row

            text = TITLE + " " + SECTION_TITLE + " " + SECTION_TEXT
            terms = re.findall(r'\w+', text.lower())
            for term in terms:
                yield term, ARTICLE_ID
        except Exception as e:
            logging.error(f"Error processing line: {line}. Exception: {e}")
            # Skip the line if there's an error
            pass

    def reducer_build_index(self, term, article_ids):
        try:
            # Count term frequency (TF) for each document
            tf = defaultdict(int)
            for article_id in article_ids:
                tf[article_id] += 1

            # Calculate IDF (Inverse Document Frequency)
            idf = math.log10(5000000 / (len(tf) + 1))

            # Calculate TF-IDF score
            for article_id, freq in tf.items():
                tf_idf = (1 + math.log10(freq)) * idf
                yield term, (article_id, tf_idf)
        except Exception as e:
            logging.error(f"Error in reducer for term {term}. Exception: {e}")
            # Skip the term if there's an error
            pass

    def steps(self):
        return [
            MRStep(mapper=self.mapper_extract_terms,
                   reducer=self.reducer_build_index)
        ]

if __name__ == '__main__':
    logging.basicConfig(stream=sys.stderr, level=logging.INFO)
    Indexer.run()

