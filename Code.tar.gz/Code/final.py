#!/usr/bin/env python3
from mrjob.job import MRJob
from mrjob.step import MRStep
import csv
import argparse

class Indexer(MRJob):
    def steps(self):
        return [
            MRStep(mapper=self.mapper_tokenize,
                   reducer=self.reducer_create_index)
        ]

    def mapper_tokenize(self, _, line):
        try:
            row = next(csv.reader([line]))  # Parse CSV row
            if len(row) != 4:
                print(f"Invalid row: {row}")
                return
            ARTICLE_ID, TITLE, SECTION_TITLE, SECTION_TEXT = row
            # Tokenize the text and emit word-document pairs
            for word in SECTION_TEXT.split():
                yield (word.lower(), int(ARTICLE_ID))
        except Exception as e:
            print(f"Error parsing row: {line}, Error: {e}")

    def reducer_create_index(self, word, doc_ids):
        # Create inverted index
        doc_ids = list(set(doc_ids))  # Remove duplicates
        yield (word, doc_ids)

class Query(MRJob):
    def steps(self):
        return [
            MRStep(mapper=self.mapper_tokenize_query,
                   reducer=self.reducer_rank_documents)
        ]

    def mapper_tokenize_query(self, _, query):
        # Tokenize query and emit word-query pairs
        for word in query.split():
            yield (word.lower(), "query")

    def reducer_rank_documents(self, word, query_ids):
        # Retrieve relevant documents and rank them
        if word == "query":
            return
        inverted_index = {}
        for query_id in query_ids:
            inverted_index.setdefault(query_id, 0)
            inverted_index[query_id] += 1
        sorted_docs = sorted(inverted_index.items(), key=lambda x: x[1], reverse=True)
        for doc_id, relevance in sorted_docs:
            yield (doc_id, relevance)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Indexer and Query MRJob')
    parser.add_argument('job_type', choices=['index', 'query'], help='Type of job: index or query')
    parser.add_argument('input_path', help='Path to input file')
    parser.add_argument('--query', help='Query text (only for query job)')

    args = parser.parse_args()

    if args.job_type == 'index':
        job = Indexer(args=[args.input_path])
    elif args.job_type == 'query':
        if not args.query:
            print("Error: --query argument is required for query job")
            exit(1)
        job = Query(args=[args.input_path, '--query', args.query])

    with job.make_runner() as runner:
        runner.run()

